Wireframe:

![Wireframe](https://github.com/user-attachments/assets/8edc7055-9e2a-4b32-8e21-54b0564498e5)

LittleLemon:

![LittleLemon](https://github.com/user-attachments/assets/9812808a-697f-48e0-a5eb-0b9036c0401c)
